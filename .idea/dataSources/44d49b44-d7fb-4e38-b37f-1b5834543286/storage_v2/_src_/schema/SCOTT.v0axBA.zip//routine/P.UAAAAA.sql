create procedure P(
   a in number,
   b out number,
    c in out number
)
is
begin
  dbms_output.put_line('存储过程中a的值：'||a);
   dbms_output.put_line('存储过程中b的值：'||b);
    dbms_output.put_line('存储过程中c的值：'||c);
   b:=50;
   c:=60;
end;
/

